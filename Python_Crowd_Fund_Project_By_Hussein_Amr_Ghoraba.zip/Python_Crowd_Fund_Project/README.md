# Python_Crowd_Fund_Project
Python Scripting ---> for Crowd Funding Project
Console application
