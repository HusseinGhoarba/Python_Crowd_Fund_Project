####################################################################################

FROM ------ Hussein Amr Ghorabah
Project : ----- Crowd Fund Project -- Console App
ITI -- DevOps -- Mansoura Branch
SuperVisor : Dr/ Noha Shehab

#####################################################################################

------------->  Install:  pip install maskpass                   <-------------------

#####################################################################################
To run the project ------------> Run (MainScript.py) file
Projects data inside file ----------> data.json 
user informations inside file -------------> userdata.txt
#####################################################################################


#####################################################################################

For any information:
	email : husseinghoraba.gh@gmail.com
	whatsapp & phone : +201011619290
	
#####################################################################################
